# Welcome to the GrowBuddies Library

Hello, fellow indoor gardeners!

The GrowBuddies project is designed to help geeky gardeners like us maximize the health and enjoyment of our indoor gardens.

Please see [the GrowBuddies Documentation](https://growbuddies.readthedocs.io/en/latest/) for more information.
